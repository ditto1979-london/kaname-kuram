let handler = async (m, { conn, text, participants, isAdmin, isOwner, groupMetadata }) => {
    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    m.reply(`*─ I N V O C A R  -  T A G A L L*\n\n- Grupo : *${groupMetadata.subject}*\n- Miembros : *${participants.length}*${text ? `\n- Mensaje : ${text}\n` : ''}\n\n` + users.map(v => '✧ @' + v.replace(/@.+/, '')).join`\n` + '\n© By WhatsApp - Meta Plus', null, {
        mentions: users
    })
}

handler.help = ['tagall']
handler.tags = ['group']
handler.command = ['tagall','all','todos','invocar']
handler.admin = true
handler.group = true

export default handler
