import { cpus as _cpus, totalmem, freemem } from 'os'
import util from 'util'
import { performance } from 'perf_hooks'
import { sizeFormatter } from 'human-readable'
let format = sizeFormatter({
  std: 'JEDEC', // 'SI' (default) | 'IEC' | 'JEDEC'
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})
let handler = async (m, { conn, usedPrefix, command }) => {
  const chats = Object.entries(conn.chats).filter(([id, data]) => id && data.isChats)
  const groupsIn = chats.filter(([id]) => id.endsWith('@g.us')) //groups.filter(v => !v.read_only)
  const used = process.memoryUsage()
  const cpus = _cpus().map(cpu => {
    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
    return cpu
  })
  const cpu = cpus.reduce((last, cpu, _, { length }) => {
    last.total += cpu.total
    last.speed += cpu.speed / length
    last.times.user += cpu.times.user
    last.times.nice += cpu.times.nice
    last.times.sys += cpu.times.sys
    last.times.idle += cpu.times.idle
    last.times.irq += cpu.times.irq
    return last
  }, {
    speed: 0,
    total: 0,
    times: {
      user: 0,
      nice: 0,
      sys: 0,
      idle: 0,
      irq: 0
    }
  })
  let old = performance.now()
  
  let neww = performance.now()
  let speed = neww - old
  
let infobt = `Les presentamos a **Kaname Kuram** 🦾, ¡el nuevo y fascinante bot de asistencia para sus grupos de WhatsApp! 📱✨

🌟 **¿Qué puede hacer Kaname Kuram por tu grupo?**
1. **Invocar miembros** ➕👥: Trae rápidamente a los miembros más activos a la conversación.
2. **Dar la bienvenida** 👋🎉: Recibe a los nuevos integrantes con mensajes personalizados.
3. **Despedir miembros** 🚪🙋‍♂️: Acompaña con un mensaje amistoso a quienes dejan el grupo.
4. **Y muchas otras funciones más** 💼✨: Desde recordatorios hasta respuestas automáticas, Kaname está aquí para ayudar.

🛡️ **Importante:**
Para que Kaname pueda desplegar todas sus funciones mágicas 🧙✨, necesita ser **administrador** del grupo. 

🚀 **¿Cómo obtener a Kaname Kuram en tu grupo?**
¡Muy fácil! Solo envía un mensaje al interno del bot y pide permiso 📩. Recuerda, Kaname Kuram es un bot privado y pertenece a **Edu** 🤝💼.

¡No esperes más y lleva la organización de tu grupo al siguiente nivel con Kaname Kuram! 🎊🤩

¿Listos para la nueva era de la administración de grupos? ¡Invita a Kaname Kuram ahora mismo! 🚀🎈

**Tu equipo de soporte de Kaname Kuram 🤖💙**
`

/*conn.sendButton(m.chat, infobt, mssg.ig, null, [
  ['ꨄ︎ Apoyar', `${usedPrefix}donate`],
   ['⌬ Grupos', `${usedPrefix}gpdylux`]
 ], m)*/
 m.reply(infobt)

}
handler.help = ['info']
handler.tags = ['main']
handler.command = ['info', 'infobot', 'botinfo']

export default handler